CREATE PROCEDURE deleteWeather(IN id BIGINT)
  BEGIN
	UPDATE Weather w SET
		w.isDeleted = 1
	WHERE w.id = id;
END;

