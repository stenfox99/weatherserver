CREATE PROCEDURE updateWeather(IN id                 BIGINT, IN city VARCHAR(50), IN dateWeather DATE, IN temp DOUBLE,
                               IN windSpeed          DOUBLE, IN pressure BIGINT, IN humidity DOUBLE,
                               IN weatherDescription VARCHAR(255), IN airQuality DOUBLE)
  BEGIN
	UPDATE Weather w SET
		w.city = city, 
		w.dateWeather = dateWeather, 
		w.temp = temp,
		w.windSpeed = windSpeed, 
		w.pressure = pressure, 
		w.humidity = humidity,
		w.weatherDescription = weatherDescription, 
		w.airQuality = airQuality
	WHERE w.id = id;
END;

