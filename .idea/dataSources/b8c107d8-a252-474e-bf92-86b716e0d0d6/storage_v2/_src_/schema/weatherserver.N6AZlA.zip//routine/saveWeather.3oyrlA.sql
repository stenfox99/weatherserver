CREATE PROCEDURE saveWeather(IN city       VARCHAR(50), IN dateWeather DATE, IN temp DOUBLE, IN windSpeed DOUBLE,
                             IN pressure   BIGINT, IN humidity DOUBLE, IN weatherDescription VARCHAR(255),
                             IN airQuality DOUBLE)
  BEGIN
	INSERT INTO Weather(
		city, 
		dateWeather, 
		temp, 
		windSpeed, 
		pressure, 
		humidity,
		weatherDescription, 
		airQuality,
		isDeleted,
		createdDate
	)VALUES(
		city, 
		dateWeather, 
		temp, 
		windSpeed, 
		pressure, 
		humidity,
		weatherDescription, 
		airQuality,
		0,
		CURDATE());
END;

